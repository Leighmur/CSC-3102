/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphdemo;

/**
 * Programming Project #3
 * @author Leigh Wright
 * @date 3-27-2019
 */

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.Comparator;
import java.util.PriorityQueue; 
import java.util.concurrent.atomic.AtomicBoolean;

public class GraphDemo {

   public static final Double INFINITY = Double.POSITIVE_INFINITY;

   public static void main(String []args) throws GraphException
   {
      if (args.length != 1)
      {
         System.out.println("Usage: GraphDemo <filename>");
         System.exit(1);
      }
      City c1, c2;
      Scanner console;
      int menuReturnValue, i,j;
      Function<City,PrintStream> f = aCity -> System.out.printf("%-2d  %-30s%n",aCity.getKey(),aCity.getLabel().trim());      
      Graph<City> g = readGraph(args[0]);      
      Graph<City> gComp = complement(g);
      long s = g.size();
      menuReturnValue = -1;
      while (menuReturnValue != 0)
      {
         menuReturnValue = menu();
         switch(menuReturnValue)
         {
             case 1: //Incidence Matrix for G'
              //write code to generate the incidence matrix of of G
              //set column width to 3            
               System.out.println();
               System.out.println();
               System.out.println("Incidence Matrix For The Undirected Graph In "+args[0]);
               System.out.println();
               //Add code here
               int edgeDone = 0;
               long edgeCo = g.countEdges();
               int[][] incMatrix = new int[(int)g.size()][(int)edgeCo];
               for(int v = 0; v< g.size(); v++)
               {
                   City fromCity = new City(v+1);
                   fromCity = g.retrieveVertex(fromCity);
                   for(int w = v+1; w < g.size(); w++)
                   {
                       City toCity = new City(w+1);
                       toCity = g.retrieveVertex(toCity);
                       if(g.isEdge(fromCity, toCity))
                       {
                           incMatrix[v][edgeDone] =1;
                                    incMatrix[w][edgeDone] = -1;
                                    edgeDone++;         
                        }
                       if(g.isEdge(toCity, fromCity)){
                            incMatrix[w][edgeDone] =1;
                                    incMatrix[v][edgeDone] = -1;
                                    edgeDone++;
                       }
                       if (edgeDone >= edgeCo)
                       {
                           break;
                       }
               }
                   if (edgeDone >= edgeCo)
                   {
                       break;
                   }
               }
         for(int v = 0; v < g.size(); v++)
         {
             for(int w = 0; w < edgeCo; w++){
                 System.out.printf("%3d " ,incMatrix[v][w]);   
             }
             System.out.println("");
         }
               //End code
               System.out.printf("The graph has %d edges and its complement has %d edges.%n",g.countEdges(),gComp.countEdges());
               System.out.println();
               System.out.println();
               System.out.println();                                
               break;                                                                                                                                                                                                                        
            case 2://Shortest-path algorithm
               console = new Scanner(System.in);
               System.out.printf("Enter the source vertex: ");      
               i = console.nextInt();
               System.out.printf("Enter the destination vertex: ");      
               j = console.nextInt();
               if (g.isPath(new City(i), new City(j)) && g.isPath(new City(j), new City(i)))
               {
                  int dest;
                  double[][] cost = new double[(int)g.size()][(int)g.size()];
                  int[][] path = new int[(int)g.size()][(int)g.size()];
                  int initial = i;
                  floyd(g,cost,path);
                  System.out.printf("Shortest round trip from %s to %s:%n",g.retrieveVertex(new City(i)).getLabel().trim(),g.retrieveVertex(new City(j)).getLabel().trim());				   
                  System.out.println("=========================================================================================");
                  //Add code here to print each leg of the trip from the source to the destination
                  //using the format below, where the columns are left-aligned and the distances
                  //are displayed to the nearest hundredths.
                  //For example:
                  //Baton Rouge -> New Orleans:
                  //Baton Rouge            ->   Gonzales                  10.20 mi
                  //Gonzales               ->   Metaire                   32.00 mi
                  //Metaire                ->   New Orleans                7.25 mi
                  //Distance: 49.75 mi
                  //
                  //New Orleans -> Baton Rouge
                  //New Orleans            ->   Metaire                    8.00 mi
                  //Metaire                ->   Gonzales                  33.00 mi
                  //Gonzalen               ->   Baton Rouge               10.00 mi
                  //Distance: 51.00 mi
                  //==============================================================
                  //Round Trip Distance: 100.75 mi
                  
                 
                  //Begin Code	
                  int destin = j;
                  ArrayList<Integer> Root = new ArrayList<>();
                  Root.add(destin);
                  while(path[i-1][destin-1] != 0)
                  {
                      Root.add(path[i-1][destin-1]);
                      destin = path[i-1][destin -1];
                  }
                  int next;
                  int start =i;
                  double distance =0;
                    for(int k = Root.size()-1; k >= 0; k--)
                    {
                        next = Root.remove(k);
                        distance += cost[start-1][next-1];
                        System.out.printf("%s -> %s  %f miles %n" , g.retrieveVertex(new City(start)).getLabel().trim(), g.retrieveVertex(new City(next)).getLabel().trim(),cost[start-1][next -1]);
                        start = next;
                    }
                  
                    System.out.println("Distance : " + distance);
                   destin = i;
                   start = j;
                  Root.add(destin);
                  while(path[start-1][destin-1] != 0)
                  {
                      Root.add(path[start-1][destin-1]);
                      destin = path[start-1][destin -1];
                  }
                  
                  distance =0;
                    for(int k = Root.size()-1; k >= 0; k--)
                    {
                        
                        next = Root.remove(k);
                        distance += cost[start-1][next-1];
                        System.out.printf("%s -> %s  %f miles %n" , g.retrieveVertex(new City(start)).getLabel().trim(), g.retrieveVertex(new City(next)).getLabel().trim(),cost[start-1][next -1]);
                        start = next;
                    }
                     System.out.println("Distance : " + distance);
                  //End code                                          
                  System.out.println("=========================================================================================");
                  System.out.printf("Round Trip Distance: %.2f miles.%n%n",cost[i-1][j-1]+cost[j-1][i-1]);                               
               }
               else
                  System.out.printf("There is no path.%n%n");
               break;
            case 3: //post-order depth-first-search traversal of g'
               System.out.println();
               System.out.println("PostOrder DFS Traversal of the Complement of the Graph In "+args[0]);
               System.out.println("==========================================================================");
               
               Function <City,Void> function = city1 ->
               {
                   System.out.printf("%d %s %n", city1.getKey(), city1.getLabel());
                   return null;
               };
               
               gComp.dfsTraverse(function);
               //invoke the dfsTraverse function
               // Output should be aligned in two-column format as illustrated below:
               // 1     Charlottetown
               // 4     Halifax
               // 2     Edmonton     

               System.out.println("==========================================================================");
               System.out.println();
               System.out.println();
               break;
            case 4: //breadth-first-search traversal
               System.out.println();
               System.out.println("BFS Traversal of the Complement of the Graph In "+args[0]);
               System.out.println("==========================================================================");
               //invoke the dfsTraverse function
               function = city1 ->
                       
                {
                   System.out.printf("%d %s %n", city1.getKey(), city1.getLabel());
                   return null;
               };
               gComp.bfsTraverse(function);
                       
               // Output should be aligned in two-column format as illustrated below:
               // 1     Charlottetown
               // 4     Halifax
               // 2     Edmonton     

               System.out.println("==========================================================================");
               System.out.println();
               System.out.println();
               break;
            case 5: //Check whether g is bipartite
                System.out.println();
                AtomicBoolean bipart = new AtomicBoolean(true);
                int[] part = isBipartite(g,bipart);
                if (bipart.get())
                {
                    if (g.size() == 0)
                        System.out.println("An empty graph is vacuously bipartite.");
                    else
                    {
                        System.out.printf("The Graph is Bipartite.%n%n");
                        System.out.println("First Partition: ");
                        for (i = 1; i <= g.size(); i++)
                        {
                            if (part[i] == 1)
                                System.out.printf("%d. %s%n ",i,g.retrieveVertex(new City(i)).getLabel().trim());
                        }
                        System.out.println();
                        System.out.println("Second Partition: ");
                        int k = 0;
                        for (i = 1; i <= g.size(); i++)
                        {
                            if (part[i] == 0)
                            {
                                System.out.printf("%d. %s%n ",i,g.retrieveVertex(new City(i)).getLabel().trim());
                                k++;
                            }
                        }
                        if (k == 0)
                            System.out.println("EMPTY");
                    }
                }
                else
                    System.out.println("The graph is not bipartite.");                        
                System.out.println();
                break;                                  
            case 6: //topoSort
               System.out.println();
               int[] top = topoSort(g);
               if (top != null)
               {
                   System.out.println("Topological Sorting of The Graph In "+args[0]);
                   System.out.println("==========================================================================");           
                   for (i=1; i<=g.size(); i++)
                   {
                       c1 = g.retrieveVertex(new City(top[i-1]));
                       f.apply(c1);
                   }
                   System.out.println("==========================================================================");
               }
               else
                   System.out.println("No topological ordering possible. The digraph in "+args[0]+" contains a directed cycle.");
               System.out.printf("%n%n");
               break;
            case 7: //primMST;
               System.out.printf("Enter the root of the MST: ");
               console = new Scanner(System.in);
               j=console.nextInt();                
               int[] mst = new int[(int)g.size()];
               double totalWt = primMST(g,j,mst);
               String cityNameA,cityNameB;
               System.out.println();
               for (i=1; i<=g.size(); i++)
               {
                   if (mst[i-1] < 1)
                       cityNameA = "NONE";
                   else
                       cityNameA = g.retrieveVertex(new City(mst[i-1])).getLabel().trim();
                   cityNameB = g.retrieveVertex(new City(i)).getLabel().trim();
                       
                   System.out.printf("%d-%s parent[%d] <- %d (%s)%n",i,cityNameB,i,mst[i-1],cityNameA);
               }
               System.out.printf("The weight of the minimum spanning tree/forest is %.2f miles.%n%n",totalWt);    
               break;
            default: ;
         } //end switch
      }//end while
   }//end main

   /**
    * This method reads a text file formatted as described in the project description.
    * @param filename the name of the DIMACS formatted graph file.
    * @return an instance of a graph.
    */
   private static Graph<City> readGraph(String filename)
   {
      try
      {
         Graph<City> newGraph = new Graph();
         try (FileReader read = new FileReader(filename)) 
         {
            char temp;
            City cit1, cit2, aCity;
            String tmp;
            int k, m, vOne, vTwo, j, size=0, nEdge=0;
            Integer key, vOneKey,vTwoKey;
            Double weight;
            Scanner in = new Scanner(read);
            while (in.hasNext())
            {
                tmp = in.next();
                temp = tmp.charAt(0);
                if (temp == 'p')
                {
                    size = in.nextInt();
                    nEdge = in.nextInt();
                }
                else if (temp == 'c')
                {
                    in.nextLine();
                }
                else if (temp == 'n')
                {
                    key = in.nextInt();
                    tmp = in.nextLine();
                    aCity = new City(key,tmp);
                    newGraph.insertVertex(aCity); 
                }
                else if (temp == 'e')
                {
                    vOneKey = in.nextInt();
                    vTwoKey = in.nextInt();
                    weight = in.nextDouble();
                    cit1 = new City(vOneKey);
                    cit2 = new City(vTwoKey);
                    newGraph.insertEdge(cit1,cit2,weight); 
                }
            }
         }
         return newGraph;
      }
      catch(IOException exception)
      {
            System.out.println("Error processing file: "+exception);
      }
      return null;
   } 

   /**
    * Display the menu interface for the application.
    * @return the menu option selected.
    */  
   private static int menu()
   {
      Scanner sc = new Scanner(System.in);
      String option;
      do
      {
         System.out.println("  BASIC WEIGHTED GRAPH APPLICATION   ");
         System.out.println("=======================================================");
         System.out.println("[1] Incidence Matrix of G");
         System.out.println("[2] Floyd's Shortest Round Trip in G");
         System.out.println("[3] Postorder DFS Traversal of G Complement");
         System.out.println("[4] BFS Traversal of G Complement");
         System.out.println("[5] Check whether G is Bipartite");
         System.out.println("[6] Topological Sort Ordering of V(G)");
         System.out.println("[7] Prim's Minimum Spanning Tree in G");
         System.out.println("[0] Quit");
         System.out.println("=====================================");
         System.out.printf("Select an option: ");         
         option = sc.nextLine().trim();
         try
         {
             int pick = Integer.parseInt(option);
             if (pick < 0 || pick > 7)
             {
                System.out.println("Invalid option...Try again");
                System.out.println();
             }
             else
                return pick;
         }
         catch(NumberFormatException e)
         {
            System.out.println("Invalid option...Try again");
         }                           
      }while(true);
   }
   
   /**
    * This method creates the complement graph of the specified digraph,
    * that is a digraph whose vertices are the same but has edge (i,j)
    * if and only if (i,j) is not an edge in g, vice versa; this method should preserve
    * the specified graph and not mutate it while creating its complement.
    * @param g a directed graph (without loops)
    * @return an instance of a graph representing the complement of the 
    * specified graph with the weights set to 1
    * @throws GraphException
    */
   private static Graph<City> complement(Graph<City> g) throws GraphException
   {   
       //implement this method
       Graph<City> tGraph = new Graph<> () ; 
       for(int a = 1 ; a <= g.size(); a ++)
       {
        City uno = new City(a) ; 
        tGraph.insertVertex(g.retrieveVertex(uno));
        for(int b = 1;  b <= g.size(); b++)
        {
        City dos = new City(b); 
        if(!g.isEdge(uno, dos)) {
          tGraph.insertEdge(dos, uno, 1.);
          }
        if(!g.isEdge(dos, uno)) {
          tGraph.insertEdge(uno, dos, 1.);
           }
        }
    }
    return tGraph ;   
    }
      
   /**
    * Determines whether an undirected graph is bipartite
    * @param g an undirected graph
    * @param bipartite is true if g is bipartite, otherwise false
    * @return an array of size |G|+1. The first entry is |G| and the remaining 
    * entries are in {0,1} when g is bipartite where [i] = 0 if vertex i
    * is in the first partition and 1 if it is in the second partition;
    * if g is not bipartite NULL returned.
    */
   private static int[] isBipartite(Graph<City> g, AtomicBoolean bipartite) throws GraphException
   {
       //implement this method (Project # 4)
       
              int[] partitions = new int[(int) g.size() + 1];
       City c1;
       City c2;
       boolean part0;
       boolean part1;
       
       partitions[0] = (int) g.size();
       
       // set all vertices to not assigned
       for (int i = 1; i < partitions.length; i++)
       {
           partitions[i] = 2;
       }
       
       // iterate through each vertex and assign it a partition
       for (int v1 = 1; v1 <= g.size(); v1++)
       {
           c1 = g.retrieveVertex(new City(v1));
           
           // if vertex is not assigned a partition yet
           if (partitions[v1] == 2)
           {
               part0 = false;
               part1 = false;
               
               // check partition of adjacent vertices 
               for (int v2 = 1; v2 <= g.size(); v2++)
               {
                   c2 = g.retrieveVertex(new City(v2));
                   
                   if (g.isEdge(c1, c2))
                   {
                       if (partitions[v2] == 0)
                       {
                           part0 = true;
                       }
                       else if (partitions[v2] == 1)
                       {
                           part1 = true;
                       }
                   }
               }
               
               // if vertex has adjacent vertices in both partitions, returns false
               if (part0 && part1)
               {
                   bipartite.set(false);
                   return null;
               }
               else if (part0)
               {
                   partitions[v1] = 1;
               }
               else
               {
                   partitions[v1] = 0;
               }
           }
           
           // assign partitions to adjacent vertices
           for (int v2 = v1 + 1; v2 <= g.size(); v2++)
           {
               c2 = g.retrieveVertex(new City(v2));
               
               if (g.isEdge(c1, c2))
               {
                   if (partitions[v2] == 2)
                   {
                      if (partitions[v1] == 0)
                      {
                          partitions[v2] = 1;
                      }
                      else
                      {
                          partitions[v2] = 0;
                      } 
                   }
                   // if adjacent vertex has same partition as current vertex, return false
                   else
                   {
                      if (partitions[v1] == partitions[v2])
                      {
                          bipartite.set(false);
                          return null;
                      }
                   }
               } 
           }
       }
       
       // return true and array of partitions
       bipartite.set(true);
       return partitions;  
   }
   
   /**
    * an auxiliary method for the topoSort method.
    * @param g a weighted directed graph
    * @param v current vertex
    * @param seen a 1-D boolean matrix of vertices that
    * have been marked.
    * @param linearOrder a 1-D array containing the 
    * topologically sorted list.
    * @param index current index.
    */
   private static void dfsOut(Graph<City> g, int v, boolean seen[], int linearOrder[],AtomicInteger index) throws GraphException
   {
      //implement this method (Project # 4)

      City c1;
      City c2;
      
     seen[v] = true;
     c1 = g.retrieveVertex(new City(v+1));
    for (int i = 1; i <= (int)g.size(); i++)
    {
        c2 = g.retrieveVertex(new City (i));
        if (g.isEdge(c1, c2) && !seen[i - 1])
        dfsOut(g, i - 1, seen, linearOrder, index);
    }
        linearOrder[index.get()] = v + 1;
        index.decrementAndGet();
       
   }
   /**
    *  This method generates a listing of the vertices of a weighted
    * directed graph using the reverse dfs topological sorting.
    * @param g a weighted directed graph
    * @return an array containing a topological ordering of the vertices
    *        of g in reverse DFS order; Null is returned if the g
    *        contains a directed cycle
    */ 
   private static int[] topoSort(Graph<City> g) throws GraphException
   {
      //implement this function (Project # 4)
       
       int[] order = new int[(int) g.size()];
       boolean[] seen = new boolean[(int) g.size()];
       AtomicInteger count = new AtomicInteger((int) g.size() - 1);
       City c1;
       City c2;
       
       //check graph for directed cycle
       for (int v1 = 1; v1 <= g.size(); v1++)
       {
           c1 = g.retrieveVertex(new City(v1));
           
           for (int v2 = v1 + 1; v2 <= g.size(); v2++)
           {
               c2 = g.retrieveVertex(new City(v2));
               
               if (g.isPath(c1, c2) && g.isPath(c2, c1))
               {
                   return null;
               }
           }
       }
       
       //set all vertices to 'not visited'
       for (int i = 0; i < seen.length; i++)
       {
           seen[i] = false;
       }
       
       //call dfsOut on each vertex if it hasn't been visited
       for (int v = 0; v < seen.length; v++)
       {
           if (!seen[v])
           {
               dfsOut(g, v, seen, order, count);
           }
       }
       return order;
   }

    /**
    * This method computes the cost and path matrices using the 
    * Floyd all-pairs shortest path algorithm.
    * @param g an instance of a weighted directed graph.
    * @param dist a matrix containing distances between pairs of vertices.
    * @param path a matrix of intermediate vertices along the path between a pair
    * of vertices. 0 indicates that the two vertices are adjacent.
    * @return none.
    */
   private static void floyd(Graph<City> g, double dist[][], int path[][]) throws GraphException
   {
       double[][] preDist = new double[dist.length][dist.length];
       int[][] prePath = new int[path.length][path.length];
      //implement this method
       for(int i = 1; i <= g.size(); i++){
           for(int j =1; j <= g.size(); j++){
               if( g.isEdge(new City(i), new City(j))){
                   path[i-1][j-1] = 0;
                  dist[i-1][j-1] = g.retrieveEdge(new City(i),new City(j));
               }else{
                   path[i-1][j-1] = -1;
                           dist[i-1][j-1] = INFINITY;
               } 
           }         
       }
          for (int i = 0; i < dist.length; i++)
       {
           for (int j = 0; j < dist.length; j++)
           {
               preDist[i][j] = dist[i][j];
               prePath[i][j] = path[i][j];
           }
       }
       
       for(int k = 1; k <= g.size(); k++){
           for(int l = 1; l <= g.size(); l++){
               for(int m = 1; m <= g.size(); m++){
                   if((preDist[l - 1][k - 1] != INFINITY) && (preDist[k - 1][m - 1] != INFINITY) && 
                           (preDist[l - 1][m - 1] > preDist[l - 1][k - 1] + preDist[k - 1][m - 1]))
                   {
                         if (prePath[k - 1][m - 1] == 0)
                          {
                              path[l - 1][m - 1] = k;
                          }
                          else
                          {
                              path[l - 1][m - 1] = prePath[k - 1][m - 1];
                          }
                       dist[l - 1][m - 1] = dist[l - 1][k-1] + dist[k-1][m - 1];
                   }
               }
            }
             for (int i = 0; i < dist.length; i++)
           {
               for (int j = 0; j < dist.length; j++)
               {
                   preDist[i][j] = dist[i][j];
                   prePath[i][j] = path[i][j];
                }
           }
       }
        for (int i1 = 0; i1< g.size(); i1++)
               {
                   for (int j1 = 0; j1 < g.size(); j1++)
                   {
                       System.out.printf("%5d ", path[i1][j1]);
                   }
                   System.out.println();
   }
   }
  
   /**
    * This method generates a minimum spanning tree rooted at a given
    * vertex, root. If no such MST exists, then it generates a minimum
    * spanning forest.
    * @param g a weighted directed graph
    * @param r root of the minimum spanning tree, when one exists.
    * @param parent the parent implementation of the minimum spanning tree/forest
    * @return the weight of such a tree or forest.
    * @throws GraphException when this graph is empty
    * <pre>
    * {@code
    * If a minimum spanning tree rooted at r is in the graph,
    * the parent implementation of a minimum spanning tree or forest is
    * determined. If no such tree exist, the parent implementation 
    * of an MSF is generated. If the tree is empty, an exception 
    * is generated.
    * }
    * </pre>
    */ 
   private static double primMST(Graph<City> g, int root, int [] parent) throws GraphException
   {
      //implement this method (Project # 4)
      //local class to represent vertices of the graph
      class Node
      {
         public int parent, id;
         public double key;
         public Node()
         {
         
         }
         public Node(int p, int v, double k)
         {
            parent = p;
            id = v;
            key = k;
         }           
      }

      Comparator<Node> cmp = (v1, v2) -> 
      {
         double d = v1.key - v2.key;
         if (d < 0)
            return -1;
         if (d > 0)
            return 1;
         d = v1.id - v2.id;
         if (d < 0)
            return -1;
         if (d > 0)
            return 1;
         return 0;           
      };

      return 0;                 
   }           
    
}
