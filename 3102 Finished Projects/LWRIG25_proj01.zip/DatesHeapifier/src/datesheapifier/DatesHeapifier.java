/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datesheapifier;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 *A testbed for a binary heap implementation and the 
 * heap sort algorithm using various comparators
 * @author Leigh Wright
 * @since 2-13-2019
 */
public class DatesHeapifier {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, HeapException 
    {
        String filename = args[0];
        Scanner sc = new Scanner(new FileReader(args[0]));
        String line;
        String[] dates;
        int month;
        int day;
        int year;
        
        ArrayList<Date>allDates = new ArrayList(); //must initialize aDateHeap
        
        while((line = sc.nextLine()).compareTo("") != 0) 
        // Makes sure the scanner isn't empty
        {
            dates = new String[3];
            dates = line.split("/");
            month = Integer.parseInt(dates[0]);
            day = Integer.parseInt(dates[1]);
            year = Integer.parseInt(dates[2]);
            allDates.add(new Date(month,day,year));
        }
        sc.close();
        
        System.out.printf("Dates from %s in Descending Order: %n", "BundesHoliday.txt");
        
        Comparator<Date> cmp = (x,y)  -> x.compareTo(y);
        Comparator<Date> cmpMin = cmp.reversed();
        Heap datesHeaped = new Heap(cmp);
        
        allDates.forEach((i) -> {datesHeaped.insert(i);});
        
        Date aDateFromHeap;
        
        while(!datesHeaped.isEmpty())
        {
            aDateFromHeap = (Date)datesHeaped.remove();
            System.out.printf("%s, %s, %d, %d%n", aDateFromHeap.getDayOfWeek(),aDateFromHeap.getMonthName(),
                    aDateFromHeap.getDay(),aDateFromHeap.getYear());
        }
        
        System.out.printf("Dates from %s in Ascending Order:%n", "BundesHoliday.txt");
        
        cmp = (Date x, Date y) -> x.compareTo(y) * - 1;
        
        Heap heap22 = new Heap(cmp);
        allDates.forEach((i) -> {heap22.insert(i);});
        
        while(!heap22.isEmpty())
        
        {
        aDateFromHeap = (Date)heap22.remove();
        System.out.printf("%s, %s, %d, %d%n", aDateFromHeap.getDayOfWeek(),aDateFromHeap.getMonthName(),
                    aDateFromHeap.getDay(),aDateFromHeap.getYear());
        }
        
        Heap heap33 = new Heap(cmp);
        sc = new Scanner(new FileReader(filename));
        
        while((line = sc.nextLine()).compareTo("") !=0)
            // Makes sure the scanner isn't empty again
        {
            dates = new String[3];
            dates =line.split("/");
            month = Integer.parseInt(dates[0]);
            day = Integer.parseInt(dates[1]);
            year = Integer.parseInt(dates[2]);
            heap33.insert(new Date(month,day,2019));
        }
        
        while(!heap33.isEmpty()){
            aDateFromHeap = (Date)heap33.remove();
            System.out.printf("%s, %s, %d %n", aDateFromHeap.getDayOfWeek(),
                    aDateFromHeap.getMonthName(), aDateFromHeap.getDay());
        }
        
    }
}
