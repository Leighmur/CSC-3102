/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datesheapifier;

import java.util.*;

/**
 *
 * @author Leigh Wright
 */
public class Heap<E extends Comparable<E>> implements HeapAPI<E> {
    
    /**
    * A complete tree stored in an array list representing this 
    * binary heap
    */
   private ArrayList<E> tree;
   /**
    * A comparator lambda function that compares two elements of this
    * heap when rebuilding it; cmp.compare(x,y) gives 1. negative when x less than y
    * 2. positive when x greater than y 3. 0 when x equal y
    */   
   
   private Comparator<? super E> cmp = (x,y) -> x.compareTo(y);
   
   /**
    * Constructs an empty heap using the compareTo method of its data type as the 
	* comparator
    */
   public Heap()
   {//implement this method
       tree = new ArrayList<>();
       cmp = (object1,object2) -> object1.compareTo(object2);
   }
   
   /**
    * A parameterized constructor that uses an externally defined comparator    
    * @param fn - a trichotomous integer value comparator function   
    */
   public Heap(Comparator<? super E> fn)
   {//implement this method

       tree = new ArrayList<>();
       fn = cmp;
   }

   public boolean isEmpty()
   {
      // implement this method
       return tree.isEmpty();
   }

   public void insert(E obj)
   {
       tree.add(obj);
       int index = tree.size() - 1;
       while (index > 0 &&cmp.compare(tree.get(index), tree.get(parent(index))) > 0){
           swap(index, parent(index));
           index = parent(index);
       }
       
   }

   public E remove() throws HeapException
   {//implement this method

       if (tree.isEmpty()){
           throw new HeapException("Heap is empty");
       }
       E obj = tree.get(0);
       int lastIndex = tree.size() - 1;
       tree.set(0,tree.get(lastIndex));
       tree.remove(lastIndex);
       rebuild(0,tree.size());
       return obj;
   }
 
   public E peek() throws HeapException
   {//implement this method

       if (tree.isEmpty()){
           throw new HeapException("Heap is empty");
       }
       return tree.get(0);
   }

   public int size()
   {//implement this method
       return tree.size();
   }
   
   /**
    * Swaps a parent and child elements of this heap at the specified indices
    * @param place an index of the child element on this heap
    * @param parent an index of the parent element on this heap
    */
   private void swap(int place, int parent)
   {//implement this method

       E temp = tree.get(parent);
       tree.set(parent, tree.get(place));
       tree.set(place, temp);
       
   }

   /**
    * Rebuilds the heap to ensure that the heap property of the tree is preserved.
    * @param root the root index of the sub-tree to be rebuilt
	* @param eSize the size of the sub-tree to be rebuilt
    */
   private void rebuild(int root, int eSize)
   {//implement this method

       int left = left(root);
       int right = right(root);
       int small = root;
       
       if (left <= eSize - 1 && cmp.compare(tree.get(left), tree.get(root)) > 0) {
            small = left;
        }
        if (right <= eSize - 1 && cmp.compare(tree.get(right), tree.get(small)) > 0) {
            small = right;
        }
        if (small != root) {
            swap(root, small);
            rebuild(small, eSize);
        }
   }
    
   private int parent(int index) {
        return (index-1)/2;
    }

    private int left(int index) {
        return 2*index+1;
    }

    private int right(int index) {
        return 2*index+2;
    }
   
}
